//
//  ConstraintAnimationViewController.swift
//  AnimationDev
//
//  Created by David Kababyan on 17/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class ConstraintAnimationViewController: UIViewController {

    //MARK: IBOutlets
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var newsletterView: UIView!
    @IBOutlet weak var newsletterCenterX: NSLayoutConstraint!
    @IBOutlet weak var welcomeLabelCenterX: NSLayoutConstraint!
    
    
    
    //MARK: Class Variables
    var newsletterInfoLabel = UILabel()
    

    //MARK: View lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNewsletterLabel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Todo: Offscreen positioning
        welcomeLabelCenterX.constant -= AnimationManager.screenBounds.width
        newsletterCenterX.constant -= AnimationManager.screenBounds.width
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Todo: Fire initial animations
        animateViewsOnScreen()
    }
    
    // MARK: Actions
    
    @IBAction func moreInfoButtonPressed(_ sender: Any) {
        
        animateNewsletterHeight()
    }
    
    
    // MARK: Animations
    func animateViewsOnScreen() {
        
        UIView.animate(withDuration: 1.5, delay: 0.25, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            
            self.welcomeLabelCenterX.constant += AnimationManager.screenBounds.width
            self.newsletterCenterX.constant += AnimationManager.screenBounds.width
            
            self.view.layoutIfNeeded()
            
        }, completion: nil)
    }
    
    func animateNewsletterHeight() {
        
        if let heightConstraint = newsletterView.returnConstraint(withId: "newsLetterHeight") {
            
            heightConstraint.constant = 350
        } else {
            print("we have no constraint with that ID")
        }
        
        UIView.animate(withDuration: 1.8, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: [], animations: {
            
            self.view.layoutIfNeeded()
        }) { (completed) in
            self.addDynamicInfoLabel()
        }
    }
    
    func addDynamicInfoLabel() {
        
        newsletterView.addSubview(newsletterInfoLabel)
        
        let xAnchor = newsletterInfoLabel.centerXAnchor.constraint(equalTo: newsletterView.leftAnchor, constant: -75)
        
        let yAnchor = newsletterInfoLabel.centerYAnchor.constraint(equalTo: newsletterView.centerYAnchor)
        
        let widhtAnchor = newsletterInfoLabel.widthAnchor.constraint(equalTo: newsletterView.widthAnchor, multiplier: 0.75)
        
        let heightAnchor = newsletterInfoLabel.heightAnchor.constraint(equalTo: newsletterInfoLabel.widthAnchor)
        
        NSLayoutConstraint.activate([xAnchor, yAnchor, widhtAnchor, heightAnchor])
        
        self.view.layoutIfNeeded()
        
        //to do: animate label in
        
        UIView.animate(withDuration: 1.0) {
            xAnchor.constant = self.newsletterView.frame.width / 2
            self.newsletterInfoLabel.alpha = 1
            self.view.layoutIfNeeded()
        }
        
    }
    
    
    
    //MARK: UISetup
    func setupNewsletterLabel() {
        newsletterInfoLabel.backgroundColor = .clear
        newsletterInfoLabel.text = "Help us make your animations much better by subscribing to our weekly newsletter! \n\n It's free and you can unsubscribe any time without hurting our feelings...much :)"
        newsletterInfoLabel.font = UIFont(name: "Bodoni 72 Oldstyle", size: 15)
        newsletterInfoLabel.textColor = .darkGray
        newsletterInfoLabel.textAlignment = .center
        newsletterInfoLabel.alpha = 1
        newsletterInfoLabel.backgroundColor = .clear
        newsletterInfoLabel.translatesAutoresizingMaskIntoConstraints = false
        newsletterInfoLabel.numberOfLines = 0
    }
    

}
