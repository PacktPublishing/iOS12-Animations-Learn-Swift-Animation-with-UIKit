//
//  SpringAnimationsViewController.swift
//  AnimationDev
//
//  Created by David Kababyan on 17/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class SpringAnimationsViewController: UIViewController {

    //MARK: IBOutlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var loginSegmentControllerOutlet: UISegmentedControl!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var continueButtonOutlet: UIButton!
    
    @IBOutlet weak var textfieldContainerView: UIView!
    
    
    
    
    //MARK: Class vars
    let repeatPasswordTextField = UITextField()

    
    //MARK: View lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createRepeatPasswordTextField()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Todo: Animation setup
        titleLabel.alpha = 0
        continueButtonOutlet.isHidden = true
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Todo: Fire initial animations
        animateTitleLabelWithSpring()
        showContinueButton()
    }

    
    
    //MARK: IBActions
    @IBAction func loginSegmentControllerValueChanged(_ sender: UISegmentedControl) {
        // Todo: Toggle UI layout
        if sender.selectedSegmentIndex == 1 {
            addTextfieldWithTransition()
            moveContinueButtonDown()
        } else {
            removeTextfieldWithTransition()
            moveContinueButtonUp()
        }

    }
    
    @IBAction func continueButtonPressed(_ sender: UIButton) {
        animateContinueButtonOnClick()
        self.segueToNextViewController(segueID: Segues.toKeyframesVC, delay: 2)
    }
    
    
    
    // MARK: Animations & Transitions
    
    func animateTitleLabelWithSpring() {
        
        UIView.animate(withDuration: 2.0, delay: 0.25, usingSpringWithDamping: 0.6, initialSpringVelocity: 6, options: [], animations: {
            
            self.titleLabel.alpha = 1
            self.titleLabel.frame.origin.y += 150
            
        }, completion: nil)
        
    }
    
    func showContinueButton() {
        
        UIView.transition(with: self.continueButtonOutlet, duration: 1.0, options: [.transitionFlipFromTop], animations: {
            self.continueButtonOutlet.isHidden = false
            
        }, completion: nil)
    }
    
    
    func addTextfieldWithTransition() {
        
        UIView.transition(with: self.textfieldContainerView, duration: 1.0, options: [.transitionCrossDissolve], animations: {
            
            self.textfieldContainerView.addSubview(self.repeatPasswordTextField)
            
        }, completion: nil)
        
    }
    
    func removeTextfieldWithTransition() {
        
        UIView.transition(with: self.textfieldContainerView, duration: 0.5, options: [.transitionCrossDissolve], animations: {
            
            self.repeatPasswordTextField.removeFromSuperview()
            
        }, completion: nil)
        
    }

    
    func moveContinueButtonDown() {
        
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0, options: [.curveEaseInOut], animations: {
            
            self.continueButtonOutlet.center.y += 25
            
        }, completion: nil)
    }
    
    func moveContinueButtonUp() {
        
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0, options: [.curveEaseInOut], animations: {
            self.continueButtonOutlet.center.y -= 25
        }, completion: nil)
    }

    
    func animateContinueButtonOnClick() {
        continueButtonOutlet.center.y -= 20
        continueButtonOutlet.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        continueButtonOutlet.alpha = 0.5
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.5, options: [], animations: {
            
            self.continueButtonOutlet.center.y += 20
            self.continueButtonOutlet.transform = CGAffineTransform.identity
            self.continueButtonOutlet.alpha = 1
            
        }, completion: nil)
        
    }
    

    //MARK: Setup UI
    func createRepeatPasswordTextField() {
        
        repeatPasswordTextField.frame = CGRect(x: 0, y: (passwordTextField.frame.origin.y + passwordTextField.frame.size.height + 8), width: 225, height: 35)
        repeatPasswordTextField.placeholder = "Repeat password"
        repeatPasswordTextField.backgroundColor = .white
        repeatPasswordTextField.layer.cornerRadius = 5.0
        repeatPasswordTextField.font = UIFont.systemFont(ofSize: 14)
        repeatPasswordTextField.borderStyle = .roundedRect
        repeatPasswordTextField.contentVerticalAlignment = .center
    }

}
