//
//  KeyFrameAnimationsViewController.swift
//  AnimationDev
//
//  Created by David Kababyan on 17/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class KeyFrameAnimationsViewController: UIViewController {

    //MARK: IBOutlets
    @IBOutlet weak var marioLogoImageView: UIImageView!
    var offset: CGFloat {
        return marioLogoImageView.frame.width/2
    }
    
    //MARK: View lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Todo: Fire keyframe animation
        bounceImageWithKeyframes()
        segueToNextViewController(segueID: Segues.toConstraintsVC, delay: 8.0)
    }
    
    // MARK: Keyframe animation
    
    func bounceImageWithKeyframes() {
        
        let origin = marioLogoImageView.center
        
        UIView.animateKeyframes(withDuration: 4.0, delay: 0, options: [.repeat, .calculationModePaced], animations: {
            
            UIView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 0.25, animations: {
                self.marioLogoImageView.center = AnimationManager.screenRight
                self.marioLogoImageView.center.x -= self.offset
            })
            
            UIView.addKeyframe(withRelativeStartTime: 0.25, relativeDuration: 0.25, animations: {
                self.marioLogoImageView.center = AnimationManager.screenTop
                self.marioLogoImageView.center.y += self.offset
            })
            
            UIView.addKeyframe(withRelativeStartTime: 0.50, relativeDuration: 0.25, animations: {
                self.marioLogoImageView.center = AnimationManager.screenLeft
                self.marioLogoImageView.center.x += self.offset
            })

            UIView.addKeyframe(withRelativeStartTime: 0.75, relativeDuration: 0.25, animations: {
                self.marioLogoImageView.center = origin
            })

        }, completion: nil)
        
    }
    
    
}
