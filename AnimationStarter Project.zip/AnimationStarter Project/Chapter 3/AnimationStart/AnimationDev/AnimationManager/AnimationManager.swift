//
//  AnimationManager.swift
//  AnimationDev
//
//  Created by David Kababyan on 18/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class AnimationManager {
    
    class var screenBounds: CGRect {
        return UIScreen.main.bounds
    }
    
    class var screenRight: CGPoint {
        return CGPoint(x: screenBounds.maxX, y: screenBounds.midY)
    }
    
    class var screenTop: CGPoint {
        return CGPoint(x: screenBounds.midX, y: screenBounds.minY)
    }
    
    class var screenLeft: CGPoint {
        return CGPoint(x: screenBounds.minX, y: screenBounds.midY)
    }

    class var screenBottom: CGPoint {
        return CGPoint(x: screenBounds.midX, y: screenBounds.maxY)
    }
}
