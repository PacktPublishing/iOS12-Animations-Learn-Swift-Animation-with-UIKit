//
//  KeyFrameAnimationsViewController.swift
//  AnimationDev
//
//  Created by David Kababyan on 17/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class KeyFrameAnimationsViewController: UIViewController {

    //MARK: IBOutlets
    @IBOutlet weak var marioLogoImageView: UIImageView!
    
    
    //MARK: View lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Todo: Fire keyframe animation
    }
    
    // MARK: Keyframe animation

    
    
}
