//
//  Constants.swift
//  AnimationDev
//
//  Created by David Kababyan on 17/11/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import Foundation

struct Segues {
    static let toSpringsVC = "toSpringSeg"
    static let toKeyframesVC = "toKeyframeSeg"
    static let toConstraintsVC = "toConstraintSeg"
}
